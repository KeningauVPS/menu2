#!/bin/bash
#About this script

clear
echo -e "\e[37;1m+=================================+"
echo -e "\e[36;1m+        Script Auto Install      +" 
echo -e "\e[36;1m+         SSH & OpenVPN v1        +" 
echo -e "\e[37;1m+=================================+"
echo -e "\e[38;1m+ [For Debian 7 32 bit & 64 bit]  +"
echo -e "\e[38;1m+ [For VPS with KVM and VMWare ]  +"
echo -e "\e[37;1m+=================================+"
echo -e "\e[34;1m+  _                __      _     +" 
echo -e "\e[34;1m+ | |              /  |    | |    +" 
echo -e "\e[34;1m+ | |__   __ _ _ __`| | ___| |_   +" 
echo -e "\e[34;1m+ |  _ \ / _` | '__|| |/ __| __|  +" 
echo -e "\e[34;1m+ | | | | (_| | |  _| |\__ \ |_   +" 
echo -e "\e[34;1m+ |_| |_|\__,_|_|  \___/___/\__|  +" 
echo -e "\e[37;1m+=================================+"                     
                              

